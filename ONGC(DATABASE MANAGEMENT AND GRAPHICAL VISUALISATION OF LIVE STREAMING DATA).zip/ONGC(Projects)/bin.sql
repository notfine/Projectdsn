select * FROM w_borehole_;

SELECT * FROM W_MONTHLY_PROD_VOL_;

SELECT * FROM w_lease_;
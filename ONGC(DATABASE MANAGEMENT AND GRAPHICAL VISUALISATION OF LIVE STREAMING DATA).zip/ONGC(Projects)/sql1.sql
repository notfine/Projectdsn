Create user Projectdsn identified by admin123;
GRANT CONNECT, RESOURCE, CREATE SESSION to Projectdsn;
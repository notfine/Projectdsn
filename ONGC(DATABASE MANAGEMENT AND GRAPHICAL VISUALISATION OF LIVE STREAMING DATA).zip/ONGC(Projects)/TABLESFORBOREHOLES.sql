CREATE TABLE W_LEASE_ (
    ID NUMBER(38) PRIMARY KEY,
    LEASE_NAME VARCHAR2(255),
    BLOCK_TYPE VARCHAR2(64),
    SHAPE MDSYS.SDO_GEOMETRY
);


select * from w_lease_;

UPDATE  w_lease_ 
SET SHAPE =    MDSYS.SDO_GEOMETRY(
         1, -- 2D Cartesian coordinate system
        NULL,
        MDSYS.SDO_POINT_TYPE(72.8777, 19.0760, NULL), -- Longitude, Latitude
        NULL,
        NULL	)																				
WHERE ID=1;

UPDATE  w_lease_ 
SET SHAPE =    MDSYS.SDO_GEOMETRY(
         2, -- 2D Cartesian coordinate system
        NULL,
        MDSYS.SDO_POINT_TYPE(73.8567, 15.2993, NULL), -- Longitude, Latitude
        NULL,
        NULL	)																				
WHERE ID=2;

UPDATE  w_lease_ 
SET SHAPE =    MDSYS.SDO_GEOMETRY(
         3, -- 2D Cartesian coordinate system
        NULL,
        MDSYS.SDO_POINT_TYPE(80.2785, 13.0827, NULL), -- Longitude, Latitude
        NULL,
        NULL	)																				
WHERE ID=3;

UPDATE  w_lease_ 
SET SHAPE =    MDSYS.SDO_GEOMETRY(
         4, -- 2D Cartesian coordinate system
        NULL,
        MDSYS.SDO_POINT_TYPE(88.3639, 22.5726, NULL), -- Longitude, Latitude
        NULL,
        NULL	)																				
WHERE ID=4;

UPDATE  w_lease_ 
SET SHAPE =    MDSYS.SDO_GEOMETRY(
         5, -- 2D Cartesian coordinate system
        NULL,
        MDSYS.SDO_POINT_TYPE(72.7268, 19.9975, NULL), -- Longitude, Latitude
        NULL,
        NULL	)																				
WHERE ID=5;

UPDATE  w_lease_ 
SET SHAPE =    MDSYS.SDO_GEOMETRY(
         6, -- 2D Cartesian coordinate system
        NULL,
        MDSYS.SDO_POINT_TYPE(74.9414, 13.0827, NULL), -- Longitude, Latitude
        NULL,
        NULL	)																				
WHERE ID=6;

UPDATE  w_lease_ 
SET SHAPE =    MDSYS.SDO_GEOMETRY(
         7, -- 2D Cartesian coordinate system
        NULL,
        MDSYS.SDO_POINT_TYPE(73.6499, 21.1702, NULL), -- Longitude, Latitude
        NULL,
        NULL	)																				
WHERE ID=7;

UPDATE  w_lease_ 
SET SHAPE =    MDSYS.SDO_GEOMETRY(
         8, -- 2D Cartesian coordinate system
        NULL,
        MDSYS.SDO_POINT_TYPE(76.2701, 9.9252, NULL), -- Longitude, Latitude
        NULL,
        NULL	)																				
WHERE ID=8;

COMMIT;

ALTER TABLE W_MONTHLY_PROD_VOL_ MODIFY COLUMN OIL_VOLUME DOUBLE;

DROP TABLE W_MONTHLY_PROD_VOL_;

CREATE TABLE W_MONTHLY_PROD_VOL_ (
ID_NUMBER NUMBER(38)  PRIMARY KEY,
UBHI VARCHAR2(255) ,
PRODUCTION_DATE DATE,
OIL_VOLUME DOUBLE PRECISION,
GAS_VOLUME DOUBLE PRECISION
);

DELETE FROM w_lease_;

UPDATE  w_lease_ 
SET SHAPE =    MDSYS.SDO_GEOMETRY(
         1, -- 2D Cartesian coordinate system
        NULL,
        MDSYS.SDO_POINT_TYPE(72.8777, 19.0760, NULL), -- Longitude, Latitude
        NULL,
        NULL	)																				
WHERE ID=1;

SELECT * FROM w_lease_;

UPDATE  w_lease_ 
SET SHAPE =  MDSYS.SDO_GEOMETRY(2003, 4326, NULL, MDSYS.SDO_ELEM_INFO_ARRAY(1, 1003, 1), MDSYS.SDO_ORDINATE_ARRAY(75.865, 11, 74.9772, 12.5003, 74.1489, 12.5, 74.3147, 12.1292, 74.6958, 11.4953, 75.0917, 11,�75.865,�11))  																			
WHERE ID=1;


INSERT INTO W_LEASE_ (LEASE_SHAPE)
VALUES (MDSYS.SDO_GEOMETRY(2003, 4326, NULL, MDSYS.SDO_ELEM_INFO_ARRAY(1, 1003, 1), MDSYS.SDO_ORDINATE_ARRAY(75.865, 11, 74.9772, 12.5003, 74.1489, 12.5, 74.3147, 12.1292, 74.6958, 11.4953, 75.0917, 11,�75.865,�11)));